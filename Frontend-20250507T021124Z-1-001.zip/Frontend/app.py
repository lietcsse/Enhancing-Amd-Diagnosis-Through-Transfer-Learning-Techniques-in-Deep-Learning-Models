from flask import Flask, render_template, request, redirect, url_for
import tensorflow as tf
import numpy as np
from PIL import Image
import os

app = Flask(__name__)

# Load the trained model
model_path = r"C:\Users\Rashmitha\Desktop\frontend\model\new_amd_detection_model.keras"
model = tf.keras.models.load_model(model_path)

# Define dataset folder
DATASET_FOLDER = r"C:\project(final new)"
ALLOWED_EXTENSIONS = {"png", "jpg", "jpeg"}

# Collect all dataset image filenames
dataset_images = set()
for root, _, files in os.walk(DATASET_FOLDER):
    for file in files:
        dataset_images.add(file.lower())

def is_fundus_image(image):
    """Placeholder function to check if the uploaded image is a fundus image."""
    return True  # Replace with actual validation logic

def allowed_file(filename):
    """Check if the file has an allowed extension."""
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS

def predict_image(image_path):
    """Process the image and predict AMD vs Normal."""
    try:
        img = Image.open(image_path).convert('RGB')
        img = img.resize((256, 256))  # Match model training size

        if not is_fundus_image(img):
            return "Please upload a fundus image"

        # Convert to numpy array and normalize
        img_array = np.array(img) / 255.0
        img_array = np.expand_dims(img_array, axis=0)

        # Predict using the model
        prediction = model.predict(img_array)

        if prediction.shape == (1, 2):  # Softmax model
            amd_prob = prediction[0][0]  # AMD class probability
            normal_prob = prediction[0][1]  # Normal class probability
            
            # **DEBUGGING PRINT**
            print(f"Raw Prediction: {prediction}, AMD Probability: {amd_prob}, Normal Probability: {normal_prob}")

            # **Fix Thresholds**
            if amd_prob > 0.999:  # Require extreme confidence for AMD
                return "AMD"
            elif normal_prob > 0.40:  # Allow Normal at lower confidence
                return "Normal"
            else:
                return "Uncertain - Further Analysis Needed"

        elif prediction.shape == (1, 1):  # Sigmoid model
            prob = prediction[0][0]

            print(f"Raw Probability: {prob}")

            if prob > 0.999:
                return "AMD"
            elif prob < 0.40:
                return "Normal"
            else:
                return "Uncertain - Further Analysis Needed"

        else:
            return "Unknown Model Output"

    except Exception as e:
        print(f"Error processing image: {e}")
        return "Error"




@app.route("/", methods=["GET", "POST"])
def index():
    """Main route for uploading images and showing predictions."""
    if request.method == "POST":
        file = request.files["file"]

        if file and allowed_file(file.filename):
            filename_lower = file.filename.lower()

            # Check if the uploaded image is in the dataset
            if filename_lower not in dataset_images:
                return redirect(url_for("error_page"))

            # Ensure upload directory exists
            upload_folder = os.path.join(app.root_path, 'static', 'uploads')
            if not os.path.exists(upload_folder):
                os.makedirs(upload_folder)

            # Save uploaded image
            filepath = os.path.join(upload_folder, file.filename)
            file.save(filepath)

            # Get model prediction
            prediction = predict_image(filepath)

            # Show result page
            return render_template("result.html", prediction=prediction, image_filename=file.filename)

    return render_template("index.html")

@app.route("/error")
def error_page():
    """Redirect to error page if image is not in the dataset."""
    return render_template("error.html")

if __name__ == "__main__":
    app.run(debug=True, port=5001)
